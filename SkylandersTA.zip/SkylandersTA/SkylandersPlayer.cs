using SkylandersTA.PlayerLayers;
using System;
using Terraria.DataStructures;
using Terraria.ModLoader;
using static Terraria.ModLoader.PlayerDrawLayer;

namespace SkylandersTA
{
	public class SkylandersPlayer : ModPlayer
	{
		public static readonly PlayerDrawLayer[] WhitelistedByTransformationDraw = new[]
		{
		PlayerDrawLayers.MountBack,
		PlayerDrawLayers.MountFront,

		//It's difficult to decide which vanilla layers to not hide specifically, needs to be tweaked during production
		PlayerDrawLayers.WebbedDebuffBack,
		PlayerDrawLayers.FrozenOrWebbedDebuff,
		PlayerDrawLayers.ElectrifiedDebuffBack,
		PlayerDrawLayers.ElectrifiedDebuffFront,
		};
        internal bool transformZap;
        internal bool transformSpyro;
        public bool transformation;
        private bool hidePlayer;
        internal int transformDashTimer;

        public override void HideDrawLayers(PlayerDrawSet drawInfo)
		{
			HideDrawLayersForTransformation(drawInfo);
		}

		private void HideDrawLayersForTransformation(PlayerDrawSet drawInfo)
		{
			if (!(transformation || hidePlayer))
			{
				return;
			}

			foreach (PlayerDrawLayer layer in PlayerDrawLayerLoader.Layers)
			{
				//If layer matches whitelist, or the layer it is parented to matches whitelist, don't hide
				if (Array.IndexOf(WhitelistedByTransformationDraw, layer) > -1)
				{
					continue;
				}

				var position = layer.GetDefaultPosition();
				if (position is PlayerDrawLayer.BeforeParent beforeParent && Array.IndexOf(WhitelistedByTransformationDraw, beforeParent.Parent) > -1 ||
					position is PlayerDrawLayer.AfterParent afterParent && Array.IndexOf(WhitelistedByTransformationDraw, afterParent.Parent) > -1)
				{
					continue;
				}

				//Little hardcode
				if (layer == ModContent.GetInstance<TransformationHeadLayer>())
				{
					continue;
				}

				layer.Hide();
			}
		}
	}
}