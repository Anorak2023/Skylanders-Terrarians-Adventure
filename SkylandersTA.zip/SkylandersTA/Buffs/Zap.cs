using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using SkylandersTA.Utilities;
using SkylandersTA.Mount;
using static Terraria.ModLoader.ModContent;

namespace SkylandersTA.Buffs
{
	public class Zap : ModBuff
	{
		public override void SetStaticDefaults()
		{
			Main.buffNoTimeDisplay[Type] = true;
			Main.buffNoSave[Type] = true;
		}

		public override void Update(Player player, ref int buffIndex)
		{
			player.mount.SetMount(MountType<Mount.Zap>(), player);
			player.buffTime[buffIndex] = 10;

            player.GetModPlayer<SkylandersPlayer>().transformZap = true;
            player.GetModPlayer<SkylandersPlayer>().transformation = true;

			player.lavaImmune = true;
			player.fireWalk = true;
			player.ClearBuff(BuffID.OnFire);

			if (player.velocity.X != 0f)
			{
				if (player.IsOnStandableGround())
				{
					Dust dust = Dust.NewDustDirect(new Vector2(player.position.X - 2f, player.position.Y + player.height - 2f), player.width + 4, 4, 127, Alpha: 100, Scale: 1.25f);
					dust.noGravity = true;

					Dust dust2 = dust;
					dust2.velocity *= 0f;
				}
			}
		}
	}
}
