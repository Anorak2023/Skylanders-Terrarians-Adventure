﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace SkylandersTA.MainMenu
{
    public class SkylandersMainMenu : ModMenu
    {

        public override string DisplayName => "Skylanders Style";

        public override Asset<Texture2D> Logo => ModContent.Request<Texture2D>("SkylandersTA/MainMenu/Logo");

        public override int Music => MusicLoader.GetMusicSlot(Mod, "Music/SkylandersTitle");
    }
}
