using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using System.Collections.Generic;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using SkylandersTA.PlayerLayers;


namespace SkylandersTA.Mount
{
    public class Spyro : ModMount
    {
        public override void SetStaticDefaults()
        {
            if (!Main.dedServ)
            {
                TransformationHeadLayer.RegisterHeadIcon(Type, new TransformationHeadLayer.HeadIconInfo
                {
                    IconAsset = ModContent.Request<Texture2D>(Texture + "_HeadIcon"),
                    FixedDirection = SpriteEffects.None,
                });
            }

            MountData.spawnDust = 6;
            MountData.buff = ModContent.BuffType<Buffs.Spyro>();
            MountData.heightBoost = -26;
            MountData.fallDamage = 0.5f;
            MountData.runSpeed = 5f;
            MountData.dashSpeed = 5f;
            MountData.flightTimeMax = 0;
            MountData.fatigueMax = 0;
            MountData.jumpHeight = 10;
            MountData.acceleration = 0.25f;
            MountData.jumpSpeed = 5f;
            MountData.blockExtraJumps = false;
            MountData.totalFrames = 8;
            MountData.constantJump = false;
            int[] array = new int[MountData.totalFrames];
            for (int l = 0; l < array.Length; l++)
            {
                array[l] = 0;
            }
            MountData.playerYOffsets = array;
            MountData.xOffset = 0;
            MountData.bodyFrame = 0;
            MountData.yOffset = -4;
            MountData.playerHeadOffset = 0;
            MountData.standingFrameCount = 1;
            MountData.standingFrameDelay = 10;
            MountData.standingFrameStart = 0;
            MountData.runningFrameCount = 7;
            MountData.runningFrameDelay = 15;
            MountData.runningFrameStart = 0;
            MountData.flyingFrameCount = 1;
            MountData.flyingFrameDelay = 10;
            MountData.flyingFrameStart = 7;
            MountData.inAirFrameCount = 1;
            MountData.inAirFrameDelay = 10;
            MountData.inAirFrameStart = 7;
            MountData.idleFrameCount = 1;
            MountData.idleFrameDelay = 10;
            MountData.idleFrameStart = 0;
            MountData.idleFrameLoop = true;
            MountData.swimFrameCount = MountData.inAirFrameCount;
            MountData.swimFrameDelay = MountData.inAirFrameDelay;
            MountData.swimFrameStart = MountData.inAirFrameStart;
            if (Main.netMode != NetmodeID.Server)
            {
                MountData.textureWidth = MountData.backTexture.Width();
                MountData.textureHeight = MountData.backTexture.Height();
            }
        }

        public override void UpdateEffects(Player player)
        {
            Lighting.AddLight(player.position, 0.5f, 0.25f, 0.1f);
        }
    }
}