using Terraria.ModLoader;

namespace SkylandersTA
{
	public class SkylandersTA : Mod
	{

	}
}