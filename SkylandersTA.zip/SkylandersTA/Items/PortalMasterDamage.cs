﻿namespace SkylandersTA.Items
{
    internal class PortalMasterDamage
    {
    }
}