﻿using Terraria.ModLoader;

namespace SkylandersTA.Items
{
    internal class PortalMasterDamage : ModProjectile
    {
    }
}