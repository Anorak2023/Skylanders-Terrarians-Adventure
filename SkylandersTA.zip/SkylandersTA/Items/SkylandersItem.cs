﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.IO;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using Terraria.Utilities;

namespace SkylandersTA.Items
{
    public class SkylandersItem : ModItem
    {
        public bool isTransformation;

        public override void SetDefaults()
        {
            isTransformation = false;
        }
    }
}
