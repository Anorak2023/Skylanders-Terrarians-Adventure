using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using SkylandersTA.Mount;

namespace SkylandersTA.Items.Skylanders
{
	public class Spyro : SkylandersItem
	{
		public override void SetDefaults()
		{
			isTransformation = true;
			Item.width = 20;
			Item.height = 30;
			Item.useTime = 20;
			Item.useAnimation = 20;
			Item.useStyle = ItemUseStyleID.HoldUp;
			Item.value = Item.sellPrice(0, 0, 50, 0);
			Item.rare = ItemRarityID.Purple;
			Item.UseSound = SoundID.NPCDeath55;
			Item.noMelee = true;
            Item.mountType = ModContent.MountType<Mount.Spyro>();
            Item.buffType = ModContent.BuffType<Buffs.Spyro>();
        }
	}
}