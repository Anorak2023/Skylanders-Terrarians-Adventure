using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using SkylandersTA.Buffs;
using SkylandersTA.Items;
using SkylandersTA.Projectiles;
using SkylandersTA.Projectiles.Transform;
using SkylandersTA.Utilities;

namespace SkylandersTA.Items
{
	public class PortalMasterLink : SkylandersItem
	{
		public override void SetStaticDefaults()
		{
			ItemID.Sets.ItemsThatAllowRepeatedRightClick[Item.type] = true;
		}

		public override void SetDefaults()
		{
			isTransformation = true;
			Item.width = 30;
			Item.height = 30;
			Item.useTime = 10;
			Item.useAnimation = 10;
			Item.useStyle = ItemUseStyleID.Shoot;
			Item.noMelee = true;
			Item.value = Item.sellPrice(0, 1, 0, 0);
			Item.rare = ItemRarityID.Blue;
			Item.UseSound = SoundID.Item1;
			Item.autoReuse = true;
			Item.shoot = ModContent.ProjectileType<DumbassDamage>();
			Item.shootSpeed = 0f;
		}

		public override bool CanUseItem(Player player)
		{
			SkylandersPlayer skylandersPlayer = player.GetSkylandersPlayer();
			if (player.altFunctionUse == 2)
			{
				if (thoriumPlayer.transformSinisterAcorn)
				{
					return true;
				}
				if (thoriumPlayer.transformCyberneticSphere)
				{
					return true;
				}
				else if (thoriumPlayer.transformAmphibianEgg)
				{
					return true;
				}
				else if (thoriumPlayer.transformMagmaCharm)
				{
					return true;
				}
				else if (thoriumPlayer.transformGoldenScale)
				{
					return true;
				}
				else if (thoriumPlayer.transformVampireCatalyst)
				{
					return player.statLife > 4;
				}
				else if (thoriumPlayer.transformFakeCoin)
				{
					return true;
				}
				else if (thoriumPlayer.transformColeopteraKeepsake)
				{
					return true;
				}
			}
			else
			{
				if (thoriumPlayer.transformSinisterAcorn)
				{
					return true;
				}
				else if (thoriumPlayer.transformCyberneticSphere)
				{
					return true;
				}
				else if (thoriumPlayer.transformAmphibianEgg)
				{
					return true;
				}
				else if (thoriumPlayer.transformMagmaCharm)
				{
					return true;
				}
				else if (thoriumPlayer.transformGoldenScale)
				{
					return true;
				}
				if (thoriumPlayer.transformVampireCatalyst)
				{
					return true;
				}
				else if (thoriumPlayer.transformFakeCoin)
				{
					return true;
				}
				else if (thoriumPlayer.transformColeopteraKeepsake)
				{
					return true;
				}
			}
			return false;
		}

		public override void UseAnimation(Player player)
		{
			ThoriumPlayer thoriumPlayer = player.GetThoriumPlayer();
			if (player.altFunctionUse == 2)
			{
				if (thoriumPlayer.transformSinisterAcorn)
				{
					Item.useTime = 38;
					Item.useAnimation = 38;
					Item.shootSpeed = 5f;
				}
				else if (thoriumPlayer.transformCyberneticSphere)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 0f;
				}
				else if (thoriumPlayer.transformAmphibianEgg)
				{
					Item.useTime = 34;
					Item.useAnimation = 34;
					Item.shootSpeed = 0f;
				}
				else if (thoriumPlayer.transformMagmaCharm)
				{
					Item.useTime = 2;
					Item.useAnimation = 2;
					Item.shootSpeed = 0f;
				}
				else if (thoriumPlayer.transformGoldenScale)
				{
					Item.useTime = 28;
					Item.useAnimation = 28;
					Item.shootSpeed = 4f;
				}
				else if (thoriumPlayer.transformVampireCatalyst)
				{
					Item.useTime = 26;
					Item.useAnimation = 26;
					Item.shootSpeed = 4f;
				}
				else if (thoriumPlayer.transformFakeCoin)
				{
					Item.useTime = 38;
					Item.useAnimation = 38;
					Item.shootSpeed = 5f;
				}
				else if (thoriumPlayer.transformColeopteraKeepsake)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 0f;
				}
			}
			else
			{
				if (thoriumPlayer.transformSinisterAcorn)
				{
					Item.useTime = 30;
					Item.useAnimation = 30;
					Item.shootSpeed = 0f;
				}
				else if (thoriumPlayer.transformCyberneticSphere)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 0f;
				}
				else if (thoriumPlayer.transformAmphibianEgg)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 4f;
				}
				else if (thoriumPlayer.transformMagmaCharm)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 5f;
				}
				else if (thoriumPlayer.transformGoldenScale)
				{
					Item.useTime = 6;
					Item.useAnimation = 6;
					Item.shootSpeed = 5f;
				}
				else if (thoriumPlayer.transformVampireCatalyst)
				{
					Item.useTime = 32;
					Item.useAnimation = 32;
					Item.shootSpeed = 15f;
				}
				else if (thoriumPlayer.transformFakeCoin)
				{
					Item.useTime = 36;
					Item.useAnimation = 36;
					Item.shootSpeed = 0f;
				}
				else if (thoriumPlayer.transformColeopteraKeepsake)
				{
					Item.useTime = 10;
					Item.useAnimation = 10;
					Item.shootSpeed = 8f;
				}
			}
		}

		public override bool AltFunctionUse(Player player)
		{
			return true;
		}

		public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
		{
			ThoriumPlayer thoriumPlayer = player.GetThoriumPlayer();
			if (player.altFunctionUse == 2)
			{
				if (thoriumPlayer.transformSinisterAcorn)
				{
					SoundEngine.PlaySound(SoundID.Item19, player.position);
					int numberProjectiles = 3 + Main.rand.Next(2);
					for (int i = 0; i < numberProjectiles; i++)
					{
						Vector2 perturbedSpeed = velocity.RotatedByRandom(MathHelper.ToRadians(15));
						float scale = 1f - (Main.rand.NextFloat() * .3f);
						perturbedSpeed *= scale;
						Projectile.NewProjectile(source, position.X, position.Y - 16, perturbedSpeed.X, perturbedSpeed.Y, ModContent.ProjectileType<SquirrelNut>(), 6, 2f, player.whoAmI);
					}
				}
				if (thoriumPlayer.transformCyberneticSphere)
				{
					int bomb = ModContent.ProjectileType<LargeCyberSphereBomb>();
					if (player.ownedProjectileCounts[bomb] < 1)
					{
						Projectile.NewProjectile(source, position.X, position.Y - 6, 0f, 0f, bomb, 125, 6f, player.whoAmI);
					}
				}
				if (thoriumPlayer.transformAmphibianEgg)
				{
					SoundEngine.PlaySound(SoundID.Item111, player.position);
					Projectile.NewProjectile(source, position.X, position.Y - 14, 6f, 0f, ModContent.ProjectileType<FrogCloud>(), 0, 0f, player.whoAmI);
					Projectile.NewProjectile(source, position.X, position.Y - 14, -6f, 0f, ModContent.ProjectileType<FrogCloud>(), 0, 0f, player.whoAmI);
				}
				if (thoriumPlayer.transformMagmaCharm)
				{
					Projectile.NewProjectile(source, position.X - player.direction * 18, position.Y + 8, -player.velocity.X * 0.25f, 0f, ModContent.ProjectileType<MagmaCharmPro2>(), 0, 0f, player.whoAmI);
				}
				if (thoriumPlayer.transformGoldenScale)
				{
					Projectile.NewProjectile(source, position.X + player.direction * 8, position.Y - 22, velocity.X * 1.15f, velocity.Y, ModContent.ProjectileType<FishBubble2>(), 0, 0f, player.whoAmI);
				}
				if (thoriumPlayer.transformVampireCatalyst)
				{
					CombatText.NewText(player.getRect(), CombatTextHelper.DamagedFriendlyReduced, 4, false, false);
					player.statLife -= 4;

					Projectile.NewProjectile(source, position.X, position.Y - 10, velocity.X, velocity.Y, ModContent.ProjectileType<CatalystBlood>(), 30, 3.5f, player.whoAmI);
				}
				if (thoriumPlayer.transformFakeCoin)
				{
					SoundEngine.PlaySound(SoundID.Item50, player.position);
					int numberProjectiles = 3 + Main.rand.Next(3);
					for (int i = 0; i < numberProjectiles; i++)
					{
						Vector2 perturbedSpeed = velocity.RotatedByRandom(MathHelper.ToRadians(15));
						float scale = 1f - (Main.rand.NextFloat() * .3f);
						perturbedSpeed = perturbedSpeed * scale;
						Projectile.NewProjectile(source, position.X, position.Y - 16, perturbedSpeed.X, perturbedSpeed.Y, ModContent.ProjectileType<CoinPro>(), 20, 3f, player.whoAmI);
					}
				}
				if (thoriumPlayer.transformColeopteraKeepsake)
				{
					SoundEngine.PlaySound(SoundID.Zombie44, player.position);
					player.AddBuff(ModContent.BuffType<BeetleCarapace>(), 180, false);
					for (int k = 0; k < 12; k++)
					{
						int dust = Dust.NewDust(player.position, player.width, player.height, 98, Main.rand.Next((int)-7f, (int)7f), Main.rand.Next((int)-7f, (int)7f), 100, default(Color), 1.25f);
						Main.dust[dust].noGravity = true;
					}
				}
			}
			else
			{
				if (thoriumPlayer.transformSinisterAcorn)
				{
					player.velocity.X = 10f * player.direction;
					thoriumPlayer.transformDashTimer = 15;
				}
				if (thoriumPlayer.transformCyberneticSphere)
				{
					int bomb = ModContent.ProjectileType<CyberSphereBomb>();
					for (int i = 0; i < Main.maxProjectiles; i++)
					{
						Projectile projectile = Main.projectile[i];
						if (projectile.active && projectile.type == bomb)
						{
							projectile.ai[0]++;
						}
					}
					Projectile.NewProjectile(source, position.X, position.Y - 10, 0f, 0f, bomb, 65, 3f, player.whoAmI);
				}
				if (thoriumPlayer.transformAmphibianEgg)
				{
					Projectile.NewProjectile(source, position.X, position.Y - 16, velocity.X, velocity.Y, ModContent.ProjectileType<FrogBubble>(), 12, 3.5f, player.whoAmI);
				}
				if (thoriumPlayer.transformMagmaCharm)
				{
					Projectile.NewProjectile(source, position.X + player.direction * 14, position.Y + 4, velocity.X * 1.15f, velocity.Y, ModContent.ProjectileType<MagmaCharmPro>(), 12, 2f, player.whoAmI);
				}
				if (thoriumPlayer.transformGoldenScale)
				{
					SoundEngine.PlaySound(SoundID.Item85, player.position);
					Vector2 perturbedSpeed = velocity.RotatedByRandom(MathHelper.ToRadians(10));
					velocity = perturbedSpeed;
					Projectile.NewProjectile(source, position.X + player.direction * 8, position.Y - 20, velocity.X * 1.15f, velocity.Y, ModContent.ProjectileType<FishBubble>(), 10, 2f, player.whoAmI);
				}
				if (thoriumPlayer.transformVampireCatalyst)
				{
					SoundEngine.PlaySound(SoundID.Item17, player.position);
					float numberProjectiles = 2;
					float rotation = MathHelper.ToRadians(5);
					position += Vector2.Normalize(velocity) * 45f;
					for (int i = 0; i < numberProjectiles; i++)
					{
						Vector2 perturbedSpeed = velocity.RotatedBy(MathHelper.Lerp(-rotation, rotation, i / (numberProjectiles - 1))) * .2f;
						Projectile.NewProjectile(source, position.X, position.Y - 10, perturbedSpeed.X * 1.25f, perturbedSpeed.Y * 1.25f, ModContent.ProjectileType<CatalystTooth>(), 15, 3f, player.whoAmI);
					}
				}
				if (thoriumPlayer.transformFakeCoin)
				{
					player.velocity.X = 12f * player.direction;
					player.velocity.Y -= 3f;
					thoriumPlayer.transformDashTimer = 15;
				}
				if (thoriumPlayer.transformColeopteraKeepsake)
				{
					Vector2 perturbedSpeed = velocity.RotatedByRandom(MathHelper.ToRadians(15));
					velocity = perturbedSpeed;
					Projectile.NewProjectile(source, position.X + player.direction * 8, position.Y - 10, velocity.X, velocity.Y, ModContent.ProjectileType<BeetleThorn>(), 38, 2f, player.whoAmI);
				}
			}
			return false;
		}

		public override void ModifyTooltips(List<TooltipLine> list)
		{
			Player player = Main.LocalPlayer;
			int index3 = -1;
			for (int m = 0; m < list.Count; m++)
			{
				if (list[m].Name.Equals("Tooltip0")) { index3 = m; break; }
			}

			int index8 = -1;
			for (int m = 0; m < list.Count; m++)
			{
				if (list[m].Name.Equals("ItemName")) { index8 = m; break; }
			}

			list.Insert(index8 + 1, new TooltipLine(Mod, "TransformationTag2", "-Early Testing-"));

			foreach (TooltipLine line2 in list)
			{
				if (line2.Mod == "ThoriumMod" && line2.Name == "TransformationTag2")
				{
					line2.OverrideColor = new Color(255, 51, 51);
				}
			}

			ThoriumPlayer thoriumPlayer = player.GetThoriumPlayer();
			if (thoriumPlayer.transformSinisterAcorn)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to throw a volley of acorns"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to dash forward, damaging an enemy in the process"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "15 symbiotic damage"));
			}
			else if (thoriumPlayer.transformAmphibianEgg)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to release a toxic haze on either side of you"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to spit a heavy bubble that deals increased damage to poisoned enemies"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "12 symbiotic damage"));
			}
			else if (thoriumPlayer.transformMagmaCharm)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to leave a trail of burning napalm"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to spit a stream of burning lava"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "12 symbiotic damage"));
			}
			else if (thoriumPlayer.transformGoldenScale)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to blow a larger bubble that stuns enemies or replenishes ally breath"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to release a water-bound bubble stream"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "10 symbiotic damage"));
			}
			else if (thoriumPlayer.transformVampireCatalyst)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to spit a bouncing globule of blood at the cost of 4 life"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to fire pair of life stealing teeth"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "15 symbiotic damage"));
			}
			else if (thoriumPlayer.transformFakeCoin)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to belch a volley of coins"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to leap forward, damaging an enemy in the process"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "50 symbiotic damage"));
			}
			else if (thoriumPlayer.transformColeopteraKeepsake)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to harden your carapace, giving you damage reduction and a thorns effect briefly"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to release a storm of venomous beetle needles"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "38 symbiotic damage"));
			}
			else if (thoriumPlayer.transformCyberneticSphere)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to drop a large scale timed explosive"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to place a timed explosive that boosts you upwards"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "65 symbiotic damage"));
			}
			else
			{
				/*
				list.Insert(index3+1, new TooltipLine(mod, "transformationText", "Right click to use your transformations special attack"));
				list.Insert(index3+1, new TooltipLine(mod, "transformationText", "Left click to use your transformations basic attack"));
				*/
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Allows you to use unique abilities while transformed"));
			}
			base.ModifyTooltips(list);
		}
	}
}
