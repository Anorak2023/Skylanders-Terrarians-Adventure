using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using SkylandersTA.Buffs;
using SkylandersTA.Items;
using SkylandersTA.Projectiles;
using SkylandersTA.PortalMasterDamageClass;
using SkylandersTA.Projectiles.Transform;
using SkylandersTA.Utilities;

namespace SkylandersTA.Items
{
	public class PortalMasterLink : SkylandersItem
	{
		public override void SetStaticDefaults()
		{
			ItemID.Sets.ItemsThatAllowRepeatedRightClick[Item.type] = true;
		}

		public override void SetDefaults()
		{
			isTransformation = true;
			Item.width = 30;
			Item.height = 30;
			Item.useTime = 10;
			Item.useAnimation = 10;
			Item.useStyle = ItemUseStyleID.Shoot;
			Item.noMelee = true;
			Item.value = Item.sellPrice(0, 1, 0, 0);
			Item.rare = ItemRarityID.Blue;
			Item.UseSound = SoundID.Item1;
			Item.autoReuse = true;
			Item.shoot = ModContent.ProjectileType<PortalMasterDamage>();
			Item.shootSpeed = 0f;
		}

		public override bool CanUseItem(Player player)
		{
			SkylandersPlayer skylandersPlayer = player.GetModPlayer<SkylandersPlayer>();
			if (player.altFunctionUse == 2)
			{
				if (SkylandersPlayer.transformZap)
				{
					return true;
				}
				else if (SkylandersPlayer.transformSpyro)
				{
					return true;
				}
			}
			else
			{
				if (SkylandersPlayer.transformZap)
				{
					return true;
				}
				else if (SkylandersPlayer.transformSpyro)
				{
					return true;
				}
			}
			return false;
		}

		public override void UseAnimation(Player player)
		{
			SkylandersPlayer SkylandersPlayer = player.GetModPlayer<SkylandersPlayer>();
			if (player.altFunctionUse == 2)
			{
				if (SkylandersPlayer.transformZap)
				{
					Item.useTime = 38;
					Item.useAnimation = 38;
					Item.shootSpeed = 5f;
				}
				else if (SkylandersPlayer.transformSpyro)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 0f;
				}
			}
			else
			{
				if (SkylandersPlayer.transformZap)
				{
					Item.useTime = 30;
					Item.useAnimation = 30;
					Item.shootSpeed = 0f;
				}
				else if (SkylandersPlayer.transformSpyro)
				{
					Item.useTime = 20;
					Item.useAnimation = 20;
					Item.shootSpeed = 0f;
				}
			}
		}

		public override bool AltFunctionUse(Player player)
		{
			return true;
		}

		public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
		{
			SkylandersPlayer SkylandersPlayer = player.GetModPlayer<SkylandersPlayer>();
			if (player.altFunctionUse == 2)
			{
				if (SkylandersPlayer.transformZap)
				{
					SoundEngine.PlaySound(SoundID.Item19, player.position);
					int numberProjectiles = 3 + Main.rand.Next(2);
					for (int i = 0; i < numberProjectiles; i++)
					{
						Vector2 perturbedSpeed = velocity.RotatedByRandom(MathHelper.ToRadians(15));
						float scale = 1f - (Main.rand.NextFloat() * .3f);
						perturbedSpeed *= scale;
						Projectile.NewProjectile(source, position.X, position.Y - 16, perturbedSpeed.X, perturbedSpeed.Y, ModContent.ProjectileType<SquirrelNut>(), 6, 2f, player.whoAmI);
					}
				}
			}
			else
			{
				if (SkylandersPlayer.transformZap)
				{
					player.velocity.X = 10f * player.direction;
					SkylandersPlayer.transformDashTimer = 15;
				}
			}
			return false;
		}

		public override void ModifyTooltips(List<TooltipLine> list)
		{
			Player player = Main.LocalPlayer;
			int index3 = -1;
			for (int m = 0; m < list.Count; m++)
			{
				if (list[m].Name.Equals("Tooltip0")) { index3 = m; break; }
			}

			int index8 = -1;
			for (int m = 0; m < list.Count; m++)
			{
				if (list[m].Name.Equals("ItemName")) { index8 = m; break; }
			}

			list.Insert(index8 + 1, new TooltipLine(Mod, "TransformationTag2", "-Early Testing-"));

			foreach (TooltipLine line2 in list)
			{
				if (line2.Mod == "ThoriumMod" && line2.Name == "TransformationTag2")
				{
					line2.OverrideColor = new Color(255, 51, 51);
				}
			}

			ThoriumPlayer thoriumPlayer = player.GetThoriumPlayer();
			if (thoriumPlayer.transformSinisterAcorn)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to throw a volley of acorns"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to dash forward, damaging an enemy in the process"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "15 symbiotic damage"));
			}
			else if (thoriumPlayer.transformAmphibianEgg)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to release a toxic haze on either side of you"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to spit a heavy bubble that deals increased damage to poisoned enemies"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "12 symbiotic damage"));
			}
			else if (thoriumPlayer.transformMagmaCharm)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to leave a trail of burning napalm"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to spit a stream of burning lava"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "12 symbiotic damage"));
			}
			else if (thoriumPlayer.transformGoldenScale)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to blow a larger bubble that stuns enemies or replenishes ally breath"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to release a water-bound bubble stream"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "10 symbiotic damage"));
			}
			else if (thoriumPlayer.transformVampireCatalyst)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to spit a bouncing globule of blood at the cost of 4 life"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to fire pair of life stealing teeth"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "15 symbiotic damage"));
			}
			else if (thoriumPlayer.transformFakeCoin)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to belch a volley of coins"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to leap forward, damaging an enemy in the process"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "50 symbiotic damage"));
			}
			else if (thoriumPlayer.transformColeopteraKeepsake)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to harden your carapace, giving you damage reduction and a thorns effect briefly"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to release a storm of venomous beetle needles"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "38 symbiotic damage"));
			}
			else if (thoriumPlayer.transformCyberneticSphere)
			{
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Right click to drop a large scale timed explosive"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText2", "Left click to place a timed explosive that boosts you upwards"));
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText3", "65 symbiotic damage"));
			}
			else
			{
				/*
				list.Insert(index3+1, new TooltipLine(mod, "transformationText", "Right click to use your transformations special attack"));
				list.Insert(index3+1, new TooltipLine(mod, "transformationText", "Left click to use your transformations basic attack"));
				*/
				list.Insert(index3 + 1, new TooltipLine(Mod, "transformationText", "Allows you to use unique abilities while transformed"));
			}
			base.ModifyTooltips(list);
		}
	}
}
