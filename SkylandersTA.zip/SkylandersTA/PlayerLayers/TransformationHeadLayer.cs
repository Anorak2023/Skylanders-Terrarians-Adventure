using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using System.Collections.Generic;
using Terraria;
using Terraria.DataStructures;
using Terraria.Graphics.Renderers;
using Terraria.ModLoader;

namespace SkylandersTA.PlayerLayers
{
	public class TransformationHeadLayer : PlayerDrawLayer
	{
		public class HeadIconInfo
		{
			public Asset<Texture2D> IconAsset { get; init; }

			public SpriteEffects? FixedDirection { get; init; } = null;

			//Add more properties here if needed
		}

		private static Dictionary<int, HeadIconInfo> MountTypeToInfo { get; set; }

		//This can likely be improved to also only check if it's also called within PlayerHeadDrawRenderTargetContent context for map only
		//Otherwise it may draw in contexts outside of it where only head draws
		private static bool drawingHeadOnlyThisTick = false;

		public static void RegisterHeadIcon(int mountType, HeadIconInfo info)
		{
			MountTypeToInfo[mountType] = info;
		}

		public override void Load()
		{
			MountTypeToInfo = new();
			On_LegacyPlayerRenderer.DrawPlayerInternal += On_LegacyPlayerRenderer_DrawPlayerInternal;
		}

		private static void On_LegacyPlayerRenderer_DrawPlayerInternal(On_LegacyPlayerRenderer.orig_DrawPlayerInternal orig, LegacyPlayerRenderer self, Terraria.Graphics.Camera camera, Player drawPlayer, Vector2 position, float rotation, Vector2 rotationOrigin, float shadow, float alpha, float scale, bool headOnly)
		{
			drawingHeadOnlyThisTick = headOnly;

			orig(self, camera, drawPlayer, position, rotation, rotationOrigin, shadow, alpha, scale, headOnly);

			drawingHeadOnlyThisTick = false;
		}

		public override void Unload()
		{
			MountTypeToInfo = null;
		}

		public override bool IsHeadLayer => true;

		public override Position GetDefaultPosition()
		{
			return new Between(null, PlayerDrawLayers.Head);
		}

		public override bool GetDefaultVisibility(PlayerDrawSet drawInfo)
		{
			return drawInfo.drawPlayer.mount.Active && MountTypeToInfo.ContainsKey(drawInfo.drawPlayer.mount.Type);
		}

		protected override void Draw(ref PlayerDrawSet drawInfo)
		{
			if (!drawingHeadOnlyThisTick)
			{
				return;
			}

			if (!MountTypeToInfo.TryGetValue(drawInfo.drawPlayer.mount.Type, out var info))
			{
				return;
			}

			var position = drawInfo.Center + new Vector2(0f, -8f) - Main.screenPosition;
			position = position.Floor();

			var sDir = info.FixedDirection ?? (drawInfo.drawPlayer.direction == 1 ? SpriteEffects.None : SpriteEffects.FlipHorizontally);

			drawInfo.DrawDataCache.Add(new DrawData(info.IconAsset.Value, position, null, Color.White, 0f, info.IconAsset.Size() * 0.5f, 1f, sDir, 0)
			{
				shader = drawInfo.drawPlayer.cMount
			});
		}
	}
}
