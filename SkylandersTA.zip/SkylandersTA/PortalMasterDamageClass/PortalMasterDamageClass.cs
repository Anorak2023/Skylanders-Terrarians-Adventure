﻿using Terraria.ModLoader;

namespace SkylandersTA.PortalMasterDamageClass
{
    public class PortalMasterDamageClass : DamageClass
    {
        internal static PortalMasterDamageClass Instance;

        public override void Load() => Instance = this;
        public override void Unload() => Instance = null;

        public override StatInheritanceData GetModifierInheritance(DamageClass damageClass)
        {
            if (damageClass == Summon || damageClass == Generic)
                return StatInheritanceData.Full;

            return StatInheritanceData.None;
        }
    }
}
